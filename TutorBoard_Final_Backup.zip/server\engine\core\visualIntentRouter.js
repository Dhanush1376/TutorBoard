/**
 * VisualIntentRouter v1.0 — The Core Decision Brain
 *
 * Single authoritative router that replaces fragmented decision-making
 * across intentEngine, chatPlannerAgent, chat.controller, and pedagogyEngine.
 *
 * INPUT:  userMessage, plannerResult, intentResult, sessionContext
 * OUTPUT: VisualIntentDecision — the ONE object that controls the entire response pipeline
 *
 * Responsibilities:
 *   - Decides: text_only | text_artifact | text_canvas | immersive | artifact_only
 *   - Prevents over-generation (no canvas for "what is X?")
 *   - Selects renderer mode, teaching mode, streaming strategy
 *   - Selects interaction depth based on query complexity
 *   - Returns a single unified decision consumed by chat.controller.js
 */

import { TEACHING_MODES, detectTeachingMode, getTeachingMode, modeRequiresCanvas, getModeRenderer } from '../config/teachingModes.js';

// ─── Decision Types ──────────────────────────────────────────────────────────

/**
 * @typedef {Object} VisualIntentDecision
 * @property {'text_only'|'text_artifact'|'text_canvas'|'immersive'|'artifact_only'} responseMode
 * @property {string} teachingMode - One of TEACHING_MODES keys
 * @property {string|null} rendererType - d3, katex, matter, three, monaco, simulator, narrative, null
 * @property {'text_first'|'parallel'|'visual_first'|'progressive'} streamingStrategy
 * @property {'passive'|'interactive'|'collaborative'} interactionDepth
 * @property {string|null} artifactType - code, ui, document, table, diagram, visual, null
 * @property {'inline'|'split'|'fullscreen'|null} canvasLayout
 * @property {number} confidence - 0-1
 * @property {string} reasoning - Why this decision was made
 */

// ─── Over-Generation Guards ──────────────────────────────────────────────────

const TEXT_ONLY_PATTERNS = [
  /^(hi|hello|hey|sup|yo|good morning|good evening)/i,
  /^(who are you|what are you|what can you do|help)/i,
  /^(thanks|thank you|ok|okay|got it|understood|cool|nice)/i,
  /^(yes|no|sure|maybe|agreed|disagree)/i,
  /\b(define|meaning of|what is the definition)\b/i,
];

const ARTIFACT_ONLY_PATTERNS = [
  /^(write|create|build|generate|make)\s+(a\s+)?(code|script|function|class|component|program)/i,
  /^(create|generate|make)\s+(a\s+)?(document|table|diagram|chart|flowchart)/i,
];

const IMMERSIVE_PATTERNS = [
  /\b(deep dive|full lesson|teach me everything about|immersive|guided tour)\b/i,
  /\b(cinematic|full walkthrough|complete tutorial)\b/i,
];

// ─── Router Class ────────────────────────────────────────────────────────────

/**
 * Route a user message to the appropriate response strategy.
 *
 * @param {Object} params
 * @param {string} params.userMessage - The raw user prompt
 * @param {Object|null} params.plannerResult - Output from chatPlannerAgent
 * @param {Object|null} params.intentResult - Output from intentEngine
 * @param {Object} params.sessionContext - Active session state
 * @param {string} [params.sessionContext.activeTopic] - Current topic
 * @param {string[]} [params.sessionContext.openArtifacts] - IDs of open artifacts
 * @param {string} [params.sessionContext.activeRenderer] - Current renderer
 * @param {string} [params.sessionContext.currentTeachingMode] - Current mode
 * @param {number} [params.sessionContext.messageCount] - Messages in session
 * @returns {VisualIntentDecision}
 */
export function routeVisualIntent({ userMessage, plannerResult, intentResult, sessionContext = {} }) {
  const msg = (userMessage || '').trim();
  const planner = plannerResult || {};
  const intent = intentResult || {};
  const ctx = sessionContext;

  // ── Step 1: Detect Teaching Mode ───────────────────────────────────────
  let teachingMode = detectTeachingMode(msg);

  // If planner or intent explicitly suggest deep mode, upgrade
  if (intent.intent === 'deep' && teachingMode === 'explain') {
    teachingMode = 'visualize';
  }
  if (intent.intent === 'test_me') {
    teachingMode = 'quiz';
  }
  if (intent.intent === 'quick') {
    teachingMode = 'explain';
  }

  // If user is already in a teaching mode, respect continuity
  if (ctx.currentTeachingMode && teachingMode === 'explain') {
    const continuityModes = ['visualize', 'simulate', 'coding', 'whiteboard'];
    if (continuityModes.includes(ctx.currentTeachingMode)) {
      // Only maintain continuity if the message is a clear follow-up (referential and short, or explicit marker)
      const isReferential = /\b(it|this|that|these|those|them|they|the\s+former|the\s+latter|that\s+one|such|him|her|his|hers|its)\b/i.test(msg);
      const isShort = msg.length < 60; // Increased length but coupled with referential check
      const hasMarker = /\b(now|next|also|more|further|continue|go\s+on|again|step|back|explain|tell|show)\b/i.test(msg);
      
      // Fix A-08: Tighten follow-up logic. Length alone is not enough.
      const isFollowUp = (isReferential && isShort) || hasMarker;
      if (isFollowUp) {
        teachingMode = ctx.currentTeachingMode;
      }
    }
  }

  const modeConfig = getTeachingMode(teachingMode);

  // ── Step 2: Over-Generation Guards ─────────────────────────────────────
  // Never launch canvas for simple greetings, acknowledgments, or definitions
  const isTextOnly = TEXT_ONLY_PATTERNS.some(p => p.test(msg));
  if (isTextOnly) {
    return buildDecision({
      responseMode: 'text_only',
      teachingMode: 'explain',
      rendererType: null,
      streamingStrategy: 'text_first',
      interactionDepth: 'passive',
      artifactType: null,
      canvasLayout: null,
      confidence: 0.95,
      reasoning: 'Simple conversational message — text-only response',
    });
  }

  // ── Step 3: Immersive Mode Check ───────────────────────────────────────
  const isImmersive = IMMERSIVE_PATTERNS.some(p => p.test(msg)) || teachingMode === 'immersive';
  if (isImmersive) {
    const renderer = resolveRenderer(intent, planner, modeConfig);
    return buildDecision({
      responseMode: 'immersive',
      teachingMode: 'immersive',
      rendererType: renderer,
      streamingStrategy: 'progressive',
      interactionDepth: 'collaborative',
      artifactType: null,
      canvasLayout: 'fullscreen',
      confidence: 0.9,
      reasoning: 'Immersive mode — fullscreen cinematic teaching experience',
    });
  }

  // ── Step 4: Artifact-Only Check (Fix A-06) ─────────────────────────────
  // Remove the planner.generate_artifact gate. Pattern match alone is enough.
  const isArtifactOnly = ARTIFACT_ONLY_PATTERNS.some(p => p.test(msg));
  if (isArtifactOnly) {
    return buildDecision({
      responseMode: 'artifact_only',
      teachingMode: teachingMode === 'explain' ? 'coding' : teachingMode,
      rendererType: null,
      streamingStrategy: 'parallel',
      interactionDepth: 'interactive',
      artifactType: planner.artifact_type || 'code',
      canvasLayout: 'split',
      confidence: 0.85,
      reasoning: `Artifact generation request — creating ${planner.artifact_type || 'code'}`,
    });
  }

  // ── Step 5: Canvas Decision ────────────────────────────────────────────
  const plannerWantsCanvas = planner.suggest_canvas === true;
  const intentWantsCanvas = intent.intent === 'deep';
  const modeWantsCanvas = modeRequiresCanvas(teachingMode);
  const canvasConfidence = calculateCanvasConfidence(plannerWantsCanvas, intentWantsCanvas, modeWantsCanvas, intent.confidence);

  const shouldUseCanvas = canvasConfidence >= 0.5;

  // ── Step 6: Artifact Decision ──────────────────────────────────────────
  const shouldGenerateArtifact = planner.generate_artifact === true;

  // ── Step 7: Determine Response Mode ────────────────────────────────────
  let responseMode = 'text_only';
  if (shouldUseCanvas && shouldGenerateArtifact) {
    responseMode = 'text_canvas'; // Canvas takes priority, artifact is secondary
  } else if (shouldUseCanvas) {
    responseMode = 'text_canvas';
  } else if (shouldGenerateArtifact) {
    responseMode = 'text_artifact';
  }

  // ── Step 8: Resolve Renderer ───────────────────────────────────────────
  const rendererType = shouldUseCanvas ? resolveRenderer(intent, planner, modeConfig) : null;

  // ── Step 9: Determine Streaming Strategy ───────────────────────────────
  const streamingStrategy = determineStreamingStrategy(responseMode, teachingMode);

  // ── Step 10: Determine Interaction Depth ───────────────────────────────
  const interactionDepth = modeConfig.interactionStyle || 'passive';

  // ── Step 11: Canvas Layout ─────────────────────────────────────────────
  let canvasLayout = null;
  if (shouldUseCanvas) {
    canvasLayout = modeConfig.layout === 'fullscreen' ? 'fullscreen' : 'split';
  }

  // ── Step 12: Build Reasoning ───────────────────────────────────────────
  const parts = [];
  if (shouldUseCanvas) parts.push(`canvas=${rendererType}`);
  if (shouldGenerateArtifact) parts.push(`artifact=${planner.artifact_type}`);
  parts.push(`mode=${teachingMode}`);
  parts.push(`conf=${canvasConfidence.toFixed(2)}`);
  const reasoning = `Route: ${responseMode} [${parts.join(', ')}]`;

  return buildDecision({
    responseMode,
    teachingMode,
    rendererType,
    streamingStrategy,
    interactionDepth,
    artifactType: shouldGenerateArtifact ? (planner.artifact_type || 'code') : null,
    canvasLayout,
    confidence: canvasConfidence,
    reasoning,
  });
}

// ─── Private Helpers ─────────────────────────────────────────────────────────

function buildDecision(overrides) {
  return {
    responseMode: 'text_only',
    teachingMode: 'explain',
    rendererType: null,
    streamingStrategy: 'text_first',
    interactionDepth: 'passive',
    artifactType: null,
    canvasLayout: null,
    confidence: 0.5,
    reasoning: '',
    ...overrides,
  };
}

/**
 * Resolve the best renderer from intent, planner, and mode signals.
 * Priority: mode override > planner canvas_type > intent renderer
 */
function resolveRenderer(intent, planner, modeConfig) {
  // Mode-specific renderer takes highest priority
  const modeRenderer = modeConfig.preferredRenderer;
  if (modeRenderer && modeRenderer !== 'auto') {
    return modeRenderer;
  }

  // Planner's canvas_type (it has the richest context)
  if (planner.canvas_type) {
    return planner.canvas_type;
  }

  // Intent engine's renderer
  if (intent.renderer && intent.renderer !== 'none') {
    return intent.renderer;
  }

  // Fallback
  return 'cinematic';
}

/**
 * Calculate canvas confidence from multiple signals.
 * Uses a weighted voting system.
 */
function calculateCanvasConfidence(plannerWants, intentWants, modeWants, intentConfidence = 0.5) {
  let score = 0;
  let weight = 0;

  // Planner signal (weight 0.4) — it has the richest context
  if (plannerWants) { score += 0.4; }
  weight += 0.4;

  // Intent signal (weight 0.35, scaled by intent confidence)
  if (intentWants) { score += 0.35 * (intentConfidence || 0.5); }
  weight += 0.35;

  // Teaching mode signal (weight 0.25)
  if (modeWants) { score += 0.25; }
  weight += 0.25;

  return weight > 0 ? score / weight : 0;
}

/**
 * Determine SSE streaming strategy based on response mode and teaching mode.
 */
function determineStreamingStrategy(responseMode, teachingMode) {
  if (responseMode === 'immersive') return 'progressive';
  if (responseMode === 'text_canvas') {
    // For canvas modes, stream text first while canvas generates in parallel
    if (teachingMode === 'simulate' || teachingMode === 'coding') return 'parallel';
    return 'progressive';
  }
  if (responseMode === 'text_artifact') return 'parallel';
  return 'text_first';
}

export default { routeVisualIntent };
