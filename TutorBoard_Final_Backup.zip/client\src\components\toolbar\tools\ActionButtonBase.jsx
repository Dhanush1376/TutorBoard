import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Check } from 'lucide-react';
import useTutorStore from '../../../store/tutorStore';

/**
 * ActionButtonBase
 *
 * Figma/Canvas-grade stateless action button (Share, Delete).
 * - Immediate effect + 2s success state with spring morphing
 * - Destructive variant uses red semantic color
 * - Accessible tooltip with consistent spring physics
 */
const ActionButtonBase = ({
  id,
  icon: Icon,
  label,
  successLabel = 'Done',
  isDestructive = false,
  onClick,
  disabled = false,
  onMouseEnter,
  onMouseLeave,
  isHoveredExternally,
  customSubmenu
}) => {
  const [didAction, setDidAction] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const { layoutView } = useTutorStore();
  const isLeftHand = layoutView === 'left';

  const handleClick = () => {
    if (disabled) return;
    if (customSubmenu) {
      setIsMenuOpen(!isMenuOpen);
    } else {
      if (onClick) onClick();
      setDidAction(true);
      setTimeout(() => setDidAction(false), 2000);
    }
  };

  const showSuccess = didAction && !isDestructive;
  const showMenu = isMenuOpen && customSubmenu;

  const [menuOffset, setMenuOffset] = useState(0);
  const menuRef = React.useRef(null);

  // EDGE-AWARE POSITIONING: Prevent submenus from going off-screen
  React.useEffect(() => {
    if (showMenu && menuRef.current) {
      const rect = menuRef.current.getBoundingClientRect();
      const padding = 12; // Screen edge padding
      let offset = 0;

      if (rect.left < padding) {
        offset = padding - rect.left;
      } else if (rect.right > window.innerWidth - padding) {
        offset = window.innerWidth - padding - rect.right;
      }

      if (offset !== 0) setMenuOffset(offset);
      else setMenuOffset(0);
    }
  }, [showMenu]);

  return (
    <div
      className="relative flex-shrink-0"
      style={{ width: '40px', height: '40px' }}
      onMouseEnter={() => {
        if (!disabled) {
          setIsHovered(true);
          onMouseEnter?.(id || label);
        }
      }}
      onMouseLeave={() => {
        setIsHovered(false);
        setIsMenuOpen(false); // Auto-close on leave
        onMouseLeave?.();
      }}
    >
      <motion.button
        whileHover={!disabled ? { y: -1 } : {}}
        whileTap={!disabled ? { scale: 0.92 } : {}}
        onClick={handleClick}
        disabled={disabled}
        aria-label={label}
        title=""
        className="relative w-full h-full flex items-center justify-center rounded-2xl outline-none transition-all duration-200"
        style={{
          cursor: disabled ? 'not-allowed' : 'pointer',
          opacity: disabled ? 0.35 : 1,
          background: showSuccess ? 'rgba(34,197,94,0.12)' : 'transparent',
        }}
      >
        {/* Shared Liquid Hover Pill */}
        {(isHovered || isHoveredExternally) && !disabled && !showSuccess && !showMenu && (
          <motion.div
            layoutId="liquid-hover-pill"
            className="absolute inset-[1.5px] rounded-[14px] z-0"
            style={{
              background: isDestructive ? 'rgba(239, 68, 68, 0.12)' : 'var(--bg-tertiary)cc',
              border: isDestructive ? '1px solid rgba(239, 68, 68, 0.2)' : '1px solid var(--border-color)',
              boxShadow: '0 2px 8px rgba(0,0,0,0.06), inset 0 0 8px rgba(255,255,255,0.03)',
            }}
            transition={{ type: 'spring', stiffness: 500, damping: 35, mass: 0.8 }}
          />
        )}

        {/* Success / Selection ring */}
        {(showSuccess || showMenu) && (
          <motion.div
            initial={{ opacity: 0, scale: 0.7 }}
            animate={{ opacity: 1, scale: 1 }}
            className="absolute inset-0 rounded-2xl z-0"
            style={{
              boxShadow: showSuccess
                ? 'inset 0 0 0 1px rgba(34,197,94,0.35)'
                : 'inset 0 0 0 1.2px var(--text-primary)',
              background: showSuccess ? 'rgba(34,197,94,0.1)' : 'transparent',
            }}
          />
        )}

        <div className="relative z-10 flex items-center justify-center">
          <AnimatePresence mode="wait">
            {showSuccess ? (
              <motion.div
                key="check"
                initial={{ scale: 0, rotate: -30, opacity: 0 }}
                animate={{ scale: 1, rotate: 0, opacity: 1 }}
                exit={{ scale: 0, opacity: 0 }}
                transition={{ type: 'spring', stiffness: 500, damping: 26 }}
              >
                <Check size={15} strokeWidth={2.5} style={{ color: 'rgb(34,197,94)' }} />
              </motion.div>
            ) : (
              <motion.div
                key="icon"
                initial={{ scale: 0.7, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.7, opacity: 0 }}
                transition={{ type: 'spring', stiffness: 500, damping: 28 }}
                className="flex items-center justify-center"
              >
                <Icon
                  size={17}
                  strokeWidth={2}
                  style={{
                    color: isDestructive
                      ? (isHovered || isHoveredExternally) ? 'rgb(239,68,68)' : 'var(--text-tertiary)'
                      : (isHovered || isHoveredExternally || showMenu)
                        ? 'var(--text-primary)'
                        : 'var(--text-tertiary)',
                    transition: 'color 0.2s ease',
                  }}
                />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.button>

      {/* Action Submenu */}
      <AnimatePresence mode="wait">
        {showMenu && (
          <motion.div
            ref={menuRef}
            initial={{ opacity: 0, y: 8, scale: 0.95 }}
            animate={{
              opacity: 1,
              y: 0,
              scale: 1,
              x: menuOffset
            }}
            exit={{ opacity: 0, y: 4, scale: 0.98 }}
            transition={{ type: 'spring', stiffness: 500, damping: 30, mass: 0.8 }}
            className={`absolute top-full mt-3 z-[9999] ${isLeftHand ? 'left-0' : 'right-0'}`}
          >
            <div
              className="bg-[var(--bg-primary)] border border-[var(--border-color)] rounded-2xl shadow-2xl relative"
              style={{
                boxShadow: '0 20px 50px -12px rgba(0,0,0,0.4), 0 0 1px rgba(255,255,255,0.1) inset',
                backdropFilter: 'blur(12px)',
              }}
              onMouseEnter={() => setIsMenuOpen(true)}
            >
              {/* Interaction Bridge: Prevents closure in the gap */}
              <div className="absolute inset-x-0 -top-3 h-3 pointer-events-auto" />

              {/* Submenu Caret removed for cleaner look */}

              <div className="rounded-2xl overflow-hidden">
                {React.isValidElement(customSubmenu)
                  ? React.cloneElement(customSubmenu, {
                    onMouseLeave: () => {
                      setIsHovered(false);
                      setIsMenuOpen(false);
                    }
                  })
                  : customSubmenu
                }
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Tooltip */}
      <AnimatePresence>
        {isHovered && !disabled && !showMenu && (
          <motion.div
            initial={{ opacity: 0, y: 6, scale: 0.94 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 3, scale: 0.97 }}
            transition={{ type: 'spring', stiffness: 600, damping: 32, mass: 0.6 }}
            role="tooltip"
            className={`absolute top-full mt-2.5 z-[9999] pointer-events-none ${isLeftHand ? 'left-0' : 'right-0'}`}
          >
            <div
              className="flex items-center gap-2 px-3 py-1.5 rounded-xl whitespace-nowrap"
              style={{
                background: isDestructive
                  ? 'rgba(220,38,38,0.95)'
                  : showSuccess
                    ? 'rgba(22,163,74,0.95)'
                    : 'rgba(var(--bg-primary-rgb), 0.85)',
                backdropFilter: 'blur(10px)',
                WebkitBackdropFilter: 'blur(10px)',
                border: `1px solid ${isDestructive
                  ? 'rgba(239,68,68,0.25)'
                  : showSuccess
                    ? 'rgba(34,197,94,0.25)'
                    : 'var(--border-color)'
                  }`,
                boxShadow: '0 12px 32px rgba(0,0,0,0.3)',
                fontFamily: 'var(--global-font)'
              }}
            >
              <span
                className="text-[11px] font-semibold tracking-tight"
                style={{
                  color: isDestructive || showSuccess ? '#fff' : 'var(--text-primary)',
                  letterSpacing: '0.02em',
                }}
              >
                {showSuccess ? successLabel : label}
              </span>
            </div>
            {/* Tooltip caret removed for cleaner look */}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default ActionButtonBase;
