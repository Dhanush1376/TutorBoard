/**
 * Agents Index
 */
export { 
  getPrompt,
  PROMPT_REGISTRY 
} from '../config/promptRegistry.js';

export { 
  PLANNER_AGENT_PROMPT 
} from './plannerAgent.js';
export { NARRATOR_AGENT_PROMPT } from './narratorAgent.js';
export { VISUALIZER_AGENT_PROMPT } from './visualizerAgent.js';
export { ANIMATOR_AGENT_PROMPT } from './animatorAgent.js';
export { CRITIC_AGENT_PROMPT } from './criticAgent.js';
export { VALIDATOR_AGENT_PROMPT } from './validatorAgent.js';

export { 
  isGreeting
} from './agentUtils.js';

export {
  detectDomain, 
  getAnimationGuide, 
  getNodeTemplates,
  getMinSteps,
  getVisualScaffold
} from '../config/domainConfig.js';

export { DOUBT_RESPONSE_PROMPT, buildDoubtPrompt } from './doubtPrompt.js';
export { classifyDoubt } from './doubtClassifier.js';
